# 📢 MHT-CET Result Checker

Automatically monitors the MHT-CET website every 15 minutes and **calls your phone** the moment results go live — using GitHub Actions (free!) + Twilio.

---

## 🚀 Setup Guide (Step by Step)

### Step 1 — Create a Free Twilio Account
1. Go to [twilio.com](https://www.twilio.com) → Sign up for free
2. After signup, go to your **Console Dashboard**
3. Note down:
   - **Account SID** (starts with `AC...`)
   - **Auth Token**
4. Go to **Phone Numbers → Get a Trial Number** → copy the number (e.g. `+12015551234`)

---

### Step 2 — Fork / Upload this repo to GitHub
1. Go to [github.com](https://github.com) → Create a new repository (e.g. `mhtcet-checker`)
2. Upload all files from this folder into that repo

---

### Step 3 — Add GitHub Secrets
1. In your GitHub repo, go to **Settings → Secrets and variables → Actions**
2. Click **New repository secret** and add these 4 secrets:

| Secret Name | Value |
|---|---|
| `TWILIO_ACCOUNT_SID` | Your Twilio Account SID |
| `TWILIO_AUTH_TOKEN` | Your Twilio Auth Token |
| `TWILIO_FROM_NUMBER` | Your Twilio number e.g. `+12015551234` |
| `YOUR_PHONE_NUMBER` | Your personal number e.g. `+919876543210` |

> ⚠️ **Your phone number must include country code** → India = `+91` followed by 10 digits

---

### Step 4 — Enable GitHub Actions
1. In your repo, go to the **Actions** tab
2. Click **"I understand my workflows, go ahead and enable them"**
3. Done! The checker now runs **every 15 minutes automatically** ✅

---

### Step 5 — Test it manually
1. Go to **Actions tab** → click **"MHT-CET Result Checker"**
2. Click **"Run workflow"** → **"Run workflow"**
3. Watch the logs — if your secrets are correct, it should run without errors

---

## 📁 File Structure

```
mhtcet-checker/
├── checker.py                    # Main Python script
├── requirements.txt              # Python dependencies
├── .github/
│   └── workflows/
│       └── check.yml             # GitHub Actions schedule
└── README.md                     # This file
```

---

## ⚙️ How It Works

```
Every 15 min
     │
     ▼
GitHub Actions runs checker.py
     │
     ▼
Downloads cetcell.mahacet.org & mahacet.org
     │
     ├─ No result keywords found → ⏳ Exit, try again in 15 min
     │
     └─ "result declared" / "scorecard" etc. found
          │
          ▼
       Twilio places a voice call to YOUR_PHONE_NUMBER 📞
       "Your MHT CET result has been declared..."
```

---

## ❓ FAQ

**Q: Will it call me multiple times?**
Yes — every 15 minutes until you disable the workflow. To stop: go to Actions → disable the workflow after results are confirmed.

**Q: Is it free?**
- GitHub Actions: Free (2000 min/month on free plan — this uses ~1 min per run, so ~2880 min/month — you may need GitHub's free tier carefully or use a paid plan)
- Twilio: Free trial gives ~$15 credit, a call costs ~₹5–10

**Q: What if the website is down temporarily?**
The script catches errors and exits gracefully — it will retry on the next run.
